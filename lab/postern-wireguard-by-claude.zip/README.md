# mnc — minimal narrow channel

A mutually authenticated, encrypted UDP channel between **explicitly enrolled
devices**, carrying only narrowly authorised application messages. One UDP port,
no web/SSH/app listeners on the public interface, no DNS, no HTTP, no CA.

## What this is (and is not)

This is **not** WireGuard, and it does not reimplement it. It implements the
*same design properties* your spec calls for, in Node, using a vetted handshake:

- Handshake: **Noise_IK** via [`noise-handshake`] — the same pattern family
  WireGuard uses. The initiator knows the responder's static key in advance;
  the responder learns and authenticates the initiator's static key. Ephemeral
  keys per session give forward secrecy.
- Transport: **ChaCha20-Poly1305** from the derived per-direction keys, with an
  explicit per-session counter and a sliding **anti-replay** window.

The crypto primitives and the handshake come from maintained libraries. The
transport framing, session handling, replay window, source guard and the narrow
application are the code in `src/`.

> For production transport between hosts that can run kernel WireGuard, prefer
> **real WireGuard** for the tunnel and run this project's *narrow application*
> (`src/app.js`) bound to the `wg` interface. Use this self-contained channel
> where you cannot run kernel WireGuard (restricted hosts, per-process channels,
> app-layer end-to-end past a tunnel gateway). See "Two roles" below.

## Your 7 points → where they live

| Your step | Code |
|---|---|
| 1. Expose one UDP port; nothing else public | `src/server.js` (single `dgram` socket) |
| 2. Pre-enrol each device's public key, trusted channel, no registration/passwords | `src/enroll.js`, `src/keys.js` (`Registry`) |
| 3. Allowlist source IPs where stable | `src/guard.js` (global) + per-peer `ips` in `peers.json` |
| 4. Authenticate before app processing; replay + forward secrecy; silence to probes; DoS cookie-like limiting | `src/channel.js` (Noise_IK, `ReplayWindow`), `src/guard.js` (handshake token bucket) |
| 5. Restrict each peer to required operations; membership ≠ general access | per-peer `ops` in `peers.json`, enforced in `src/app.js` |
| 6. Narrow app: bounded sizes, strict schema, explicit ops, no code execution | `src/app.js` (fixed handler table, hand-validated schema) |
| 7. Minimal endpoint, protected keys, clear revocation | `keys.js` writes `0600`; `enroll.js revoke`; server re-checks enrolment per message |

## Quickstart

```bash
npm install
npm test                              # 13 checks: happy path + negative cases

# generate identities (do this on trusted machines)
node src/enroll.js keygen server.key.json
node src/enroll.js keygen alice.key.json

# enrol alice's PUBLIC key with the ops she is allowed to call
node src/enroll.js add peers.json $(node src/enroll.js pub alice.key.json) ping,status,echo
# optionally pin a stable source IP:  ... ping,status --ip 203.0.113.7

# run the endpoint (one UDP port)
MNC_PORT=51820 node src/server.js
# restrict at the process too:  MNC_ALLOW_IPS=203.0.113.7,203.0.113.8 node src/server.js
```

Client side, an enrolled peer needs only its own key and the server's **public**
key (provisioned out of band):

```js
const { request } = require('./src/client')
const { loadIdentity } = require('./src/keys')
const alice = loadIdentity('alice.key.json')
const serverPub = Buffer.from(require('./server.key.json').publicKey, 'hex')

const r = await request({ identity: alice, responderStaticPub: serverPub,
                          host: '203.0.113.1', port: 51820, op: 'ping', args: {} })
// { ok: true, id: 'r1', result: { pong: true } }
```

Revoke instantly:

```bash
node src/enroll.js revoke peers.json <pubhex>
# then, on the server, registry.reload() (or restart). Live sessions for a
# revoked key are dropped on their next message.
```

## Adding an operation

Edit the fixed table in `src/app.js`. Handlers receive validated `(args, ctx)`
and return JSON-serialisable objects. They must never execute received code,
open arbitrary paths, or shell out on input. Then grant the op per peer in
`peers.json`. There is no dynamic dispatch beyond this allowlist.

## Two roles

The narrow application and the transport are separable on purpose:

- **Transport role** — get authenticated, replay-protected, forward-secret
  bytes between two known endpoints. Kernel WireGuard does this best where
  available; this project's `channel.js` does it where WireGuard can't run.
- **Application role** — decide what an authenticated peer is allowed to *do*.
  This is `app.js`: bounded input, strict schema, per-peer authority, fixed
  operations. Run it whether the bytes arrive via WireGuard or via `channel.js`.

If a WireGuard tunnel terminates at a gateway, its encryption protects only to
that gateway. Keep `app.js` (and its authority checks) at the **actual receiving
application** so protection and authorisation are end-to-end.

## Wire format

```
0x01 INIT      [type][initIdx:4][noise msg1]
0x02 RESP      [type][initIdx:4][respIdx:4][noise msg2]
0x03 TRANSPORT [type][receiverIdx:4][counter:8 BE][ciphertext]     # replay-checked after AEAD
```

## Residual limits (from your own analysis)

- **Endpoint compromise.** A stolen key or a compromised authorised device
  crosses the authentication boundary. Protect keys at rest; revoke promptly;
  keep authority per peer minimal.
- **Availability.** Encryption does not stop a flood of your link. That needs
  upstream/independent connectivity. The handshake limiter here only bounds
  *crypto* work, not bandwidth.
- **Malicious content.** An authenticated message can still carry harmful
  instructions. For an autonomous/AI receiver, authorisation of *actions* must
  be a separate control layer on top of this channel — this transport decides
  *who* is talking, not *whether the requested action is safe*.

[`noise-handshake`]: https://www.npmjs.com/package/noise-handshake
