'use strict';

const tls = require('node:tls');
const { constants } = require('node:crypto');
const { load, checkServer } = require('./lib/config');
const { ALPN, reader, frame, validateRequest } = require('./lib/protocol');

function createChannelServer(config, { audit = () => {}, onMessage = () => {} } = {}) {
  const peers = checkServer(config);
  const sockets = new Set();
  const emit = event => { try { audit(event); } catch { /* Logging cannot grant access. */ } };
  const server = tls.createServer({
    key: config.key, cert: config.cert, ca: config.ca,
    minVersion: 'TLSv1.3', maxVersion: 'TLSv1.3',
    requestCert: true, rejectUnauthorized: true,
    ALPNProtocols: [ALPN], handshakeTimeout: 3000,
    // Clients always make a fresh connection; do not rely on resumed peer identities.
    secureOptions: constants.SSL_OP_NO_TICKET
  }, socket => {
    const certificate = socket.getPeerCertificate();
    const peer = peers.get(certificate.fingerprint256);
    if (!socket.authorized || socket.alpnProtocol !== ALPN || !peer || socket.isSessionReused() ||
        socket.remoteAddress !== peer.address) return socket.destroy();

    const now = performance.now();
    peer.tokens = Math.min(20, peer.tokens + (now - peer.updated) / 1000 * 5);
    peer.updated = now;
    if (peer.tokens < 1) return socket.destroy();
    peer.tokens -= 1;

    socket.on('data', reader(value => {
      const request = validateRequest(value);
      if (!peer.operations.includes(request.op)) return socket.destroy();
      // Identity comes exclusively from the enrolled certificate, never the JSON.
      // The default callback discards content. Integrators may install a short,
      // synchronous receiver. Do not execute text or treat it as authority.
      if (request.op === 'message') onMessage(Object.freeze({
        peer: peer.id, id: request.id, text: request.body.text
      }));
      emit({ event: 'accepted', peer: peer.id, id: request.id, op: request.op,
        bytes: request.op === 'message' ? Buffer.byteLength(request.body.text) : 0 });
      socket.end(frame({ v: 1, id: request.id, ok: true,
        result: request.op === 'ping' ? 'pong' : 'accepted' }));
    }, () => socket.destroy()));
  });

  server.maxConnections = 64;
  server.on('connection', socket => {
    sockets.add(socket);
    // Absolute deadline, so a slow stream cannot keep a connection alive forever.
    const deadline = setTimeout(() => socket.destroy(), 5000);
    deadline.unref();
    socket.on('error', () => {});
    socket.once('close', () => { clearTimeout(deadline); sockets.delete(socket); });
  });
  server.on('secureConnection', socket => socket.on('error', () => {}));
  server.on('tlsClientError', () => {});

  return {
    server,
    listen: () => new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(config.port, config.host, () => {
        server.removeListener('error', reject);
        resolve(server.address());
      });
    }),
    close: () => new Promise(resolve => {
      sockets.forEach(socket => socket.destroy());
      server.close(resolve);
    })
  };
}

if (require.main === module) {
  Promise.resolve().then(() => {
    if (!process.argv[2]) throw new Error('Usage: node server.js CONFIG.json');
    const channel = createChannelServer(load(process.argv[2]), {
      audit: event => console.log(JSON.stringify(event))
    });
    channel.server.on('error', error => { console.error(error.message); process.exitCode = 1; });
    return channel.listen().then(address => {
      console.log(JSON.stringify({ event: 'listening', ...address }));
      const stop = () => channel.close().then(() => { process.exitCode = 0; });
      process.once('SIGINT', stop);
      process.once('SIGTERM', stop);
    });
  }).catch(error => { console.error(error.message); process.exitCode = 1; });
}

module.exports = { createChannelServer };
