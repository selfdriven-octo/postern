'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const tls = require('node:tls');
const net = require('node:net');
const { randomUUID } = require('node:crypto');
const { createDemo } = require('../scripts/create-demo');
const { load, checkServer } = require('../lib/config');
const { ALPN, MAX_FRAME, frame, reader } = require('../lib/protocol');
const { createChannelServer } = require('../server');
const { send } = require('../client');

let temporary, serverConfig, clientConfig, channel;
const accepted = [];

function start(config, audit = () => {}) {
  const result = createChannelServer(config, { audit });
  return new Promise((resolve, reject) => {
    result.server.once('error', reject);
    result.server.listen(0, config.host, () => resolve(result));
  });
}

before(() => {
  temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'secure-node-test-'));
  const demo = createDemo(path.join(temporary, 'identities'));
  serverConfig = load(path.join(demo, 'server.json'));
  clientConfig = load(path.join(demo, 'client.json'));
  return start(serverConfig, event => accepted.push(event)).then(result => {
    channel = result;
    clientConfig.port = result.server.address().port;
  });
});
after(() => (channel ? channel.close() : Promise.resolve()).then(() => fs.rmSync(temporary, { recursive: true, force: true })));

function raw(bytes, overrides = {}) {
  return new Promise((resolve, reject) => {
    const socket = tls.connect({ host: clientConfig.host, port: clientConfig.port,
      key: clientConfig.key, cert: clientConfig.cert, ca: clientConfig.ca,
      minVersion: 'TLSv1.3', maxVersion: 'TLSv1.3', ALPNProtocols: [ALPN],
      rejectUnauthorized: true, ...overrides });
    let received = 0;
    const timer = setTimeout(() => { socket.destroy(); reject(new Error('Test deadline')); }, 7000);
    socket.on('error', () => {});
    socket.on('data', chunk => { received += chunk.length; });
    socket.once('secureConnect', () => socket.write(bytes));
    socket.once('close', () => { clearTimeout(timer); resolve(received); });
  });
}

function rejected(bytes, overrides) {
  const count = accepted.length;
  return raw(bytes, overrides).then(received => {
    assert.equal(received, 0);
    assert.equal(accepted.length, count, 'rejected input reached application');
  });
}
const request = (op = 'ping', body = {}) => ({ v: 1, id: randomUUID(), op, body });

test('mutually authenticated ping and message round trips', () =>
  send(clientConfig, 'ping').then(result => {
    assert.equal(result.result, 'pong');
    return send(clientConfig, 'message', { text: 'Hello Octo 🔐' });
  }).then(result => {
    assert.equal(result.result, 'accepted');
    assert.equal(accepted.at(-1).peer, 'mark-device');
    assert.equal(Object.hasOwn(accepted.at(-1), 'text'), false);
  }));

test('wrong server fingerprint fails before message delivery', () => {
  const count = accepted.length;
  return assert.rejects(send({ ...clientConfig, serverFingerprint256: Array(32).fill('00').join(':') }, 'ping'))
    .then(() => assert.equal(accepted.length, count));
});

test('missing client certificate rejected', () => rejected(frame(request()), { key: undefined, cert: undefined }));
test('CA-signed but unenrolled certificate rejected', () => rejected(frame(request()), {
  key: fs.readFileSync(path.join(temporary, 'identities/unenrolled.key')),
  cert: fs.readFileSync(path.join(temporary, 'identities/unenrolled.crt'))
}));
test('untrusted server CA rejected', () => assert.rejects(send({ ...clientConfig, ca: clientConfig.cert }, 'ping')));
test('TLS 1.2 rejected', () => rejected(frame(request()), { minVersion: 'TLSv1.2', maxVersion: 'TLSv1.2' }));
test('missing application protocol rejected', () => rejected(frame(request()), { ALPNProtocols: [] }));
test('unknown operation rejected', () => rejected(frame(request('exec', { command: 'anything' }))));
test('extra fields including claimed identity rejected', () => rejected(frame({ ...request(), peer: 'admin' })));
test('oversized text rejected', () => rejected(frame(request('message', { text: 'x'.repeat(4097) }))));
test('oversized advertised frame rejected without waiting for body', () => {
  const header = Buffer.alloc(4); header.writeUInt32BE(MAX_FRAME + 1);
  return rejected(header);
});
test('malformed JSON rejected', () => rejected(Buffer.from([0, 0, 0, 1, 123])));
test('invalid UTF-8 rejected', () => rejected(Buffer.from([0, 0, 0, 1, 255])));
test('two frames in one request rejected', () => rejected(Buffer.concat([frame(request()), frame(request())])));
test('reader accepts fragmented headers and bodies', () => {
  const value = request('message', { text: 'é🔐' });
  let output;
  const read = reader(result => { output = result; }, error => { throw error; });
  for (const byte of frame(value)) read(Buffer.from([byte]));
  assert.deepEqual(output, value);
});
test('wildcard binding and missing required interface fail closed', () => {
  assert.throws(() => checkServer({ ...serverConfig, host: '0.0.0.0' }));
  assert.throws(() => checkServer({ ...serverConfig, host: '10.77.0.1' }));
  assert.throws(() => checkServer({ ...serverConfig, interface: 'nonexistent-test-interface' }));
});
test('SAN validation remains enabled', () => {
  const { X509Certificate } = require('node:crypto');
  const cert = new X509Certificate(serverConfig.cert).toLegacyObject();
  assert.equal(tls.checkServerIdentity('127.0.0.1', cert), undefined);
  assert.ok(tls.checkServerIdentity('127.0.0.2', cert) instanceof Error);
});
test('peer permission rejects otherwise authenticated message', () => {
  let count = 0;
  return start({ ...serverConfig, peers: [{ ...serverConfig.peers[0], operations: ['ping'] }] }, () => count++)
    .then(other => assert.rejects(send({ ...clientConfig, port: other.server.address().port }, 'message', { text: 'denied' }))
      .then(() => assert.equal(count, 0)).finally(() => other.close()));
});
test('peer address restriction rejects enrolled certificate from wrong address', () =>
  start({ ...serverConfig, peers: [{ ...serverConfig.peers[0], address: '127.0.0.2' }] })
    .then(other => assert.rejects(send({ ...clientConfig, port: other.server.address().port }, 'ping'))
      .finally(() => other.close())));
test('receiver gets verified identity and original text', () => {
  let message;
  const other = createChannelServer(serverConfig, { onMessage: value => { message = value; } });
  return new Promise(resolve => other.server.listen(0, serverConfig.host, resolve))
    .then(() => send({ ...clientConfig, port: other.server.address().port }, 'message', { text: 'Delivered 🔐' }))
    .then(() => {
      assert.equal(message.peer, 'mark-device');
      assert.equal(message.text, 'Delivered 🔐');
      assert.ok(Object.isFrozen(message));
    }).finally(() => other.close());
});
test('receiver exception does not acknowledge success or crash server', () => {
  const other = createChannelServer(serverConfig, { onMessage: () => { throw new Error('Receiver failed'); } });
  return new Promise(resolve => other.server.listen(0, serverConfig.host, resolve))
    .then(() => assert.rejects(send({ ...clientConfig, port: other.server.address().port }, 'message', { text: 'Rejected' })))
    .then(() => send({ ...clientConfig, port: other.server.address().port }, 'ping'))
    .then(result => assert.equal(result.result, 'pong')).finally(() => other.close());
});
test('per-peer burst limit rejects excess authenticated connections', () =>
  start(serverConfig).then(other => Promise.allSettled(Array.from({ length: 30 }, () =>
    send({ ...clientConfig, port: other.server.address().port }, 'ping'))).then(results => {
      assert.ok(results.some(r => r.status === 'fulfilled'));
      assert.ok(results.some(r => r.status === 'rejected'));
    }).finally(() => other.close())));
test('partial application frame is closed by absolute deadline', () => {
  const started = Date.now();
  return raw(Buffer.from([0])).then(received => {
    assert.equal(received, 0);
    assert.ok(Date.now() - started < 6500);
  });
});
test('raw TCP client cannot hold handshake indefinitely', () => new Promise((resolve, reject) => {
  const socket = net.connect(clientConfig.port, clientConfig.host);
  const timer = setTimeout(() => { socket.destroy(); reject(new Error('Handshake not bounded')); }, 6500);
  socket.on('error', () => {});
  socket.on('close', () => { clearTimeout(timer); resolve(); });
}));
