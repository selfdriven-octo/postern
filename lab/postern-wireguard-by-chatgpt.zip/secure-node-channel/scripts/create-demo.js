'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { randomBytes, X509Certificate } = require('node:crypto');

function createDemo(directory) {
  const destination = path.resolve(directory);
  // Refuse to overwrite identities, configs or an existing directory.
  fs.mkdirSync(destination, { mode: 0o700 });
  const previousMask = process.umask(0o077);
  const run = args => {
    const result = spawnSync('openssl', args, { cwd: destination, encoding: 'utf8' });
    if (result.error || result.status !== 0) throw new Error(result.error?.message || result.stderr);
  };
  const write = (name, value) => fs.writeFileSync(path.join(destination, name), value, { mode: 0o600, flag: 'wx' });
  try {
    run(['req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:P-256', '-nodes',
      '-keyout', 'ca.key', '-out', 'ca.crt', '-days', '30', '-subj', '/CN=Local Demo CA',
      '-addext', 'basicConstraints=critical,CA:TRUE,pathlen:0', '-addext', 'keyUsage=critical,keyCertSign,cRLSign']);
    for (const name of ['server', 'client', 'unenrolled']) {
      run(['req', '-new', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:P-256', '-nodes',
        '-keyout', name + '.key', '-out', name + '.csr', '-subj', '/CN=' + name]);
      write(name + '.ext', 'basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature\n' +
        'extendedKeyUsage=' + (name === 'server' ? 'serverAuth\nsubjectAltName=IP:127.0.0.1,IP:10.77.0.1\n' : 'clientAuth\n'));
      run(['x509', '-req', '-in', name + '.csr', '-CA', 'ca.crt', '-CAkey', 'ca.key',
        '-set_serial', '0x' + randomBytes(16).toString('hex'), '-out', name + '.crt',
        '-days', '7', '-sha256', '-extfile', name + '.ext']);
      fs.unlinkSync(path.join(destination, name + '.csr'));
      fs.unlinkSync(path.join(destination, name + '.ext'));
    }
    const fingerprint = name => new X509Certificate(fs.readFileSync(path.join(destination, name + '.crt'))).fingerprint256;
    write('server.json', JSON.stringify({ host: '127.0.0.1', port: 9443,
      key: 'server.key', cert: 'server.crt', ca: 'ca.crt',
      peers: [{ id: 'mark-device', fingerprint256: fingerprint('client'), address: '127.0.0.1', operations: ['ping', 'message'] }]
    }, null, 2) + '\n');
    write('client.json', JSON.stringify({ host: '127.0.0.1', port: 9443,
      key: 'client.key', cert: 'client.crt', ca: 'ca.crt', serverFingerprint256: fingerprint('server')
    }, null, 2) + '\n');
  } finally { process.umask(previousMask); }
  return destination;
}

if (require.main === module) {
  try { console.log('Created local-only demo: ' + createDemo(process.argv[2] || 'demo')); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = { createDemo };
