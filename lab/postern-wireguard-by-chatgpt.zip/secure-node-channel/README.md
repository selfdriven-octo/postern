# Secure Node Channel

A runnable CommonJS Node.js client/server for small, explicitly authorised messages.
Uses `.then()`, Node's built-in TLS and no npm dependencies.

The recommended deployment is **IP → UDP → WireGuard → inner IP/TCP → TLS 1.3 with mutual authentication → bounded messages**.
WireGuard is supplied by the operating system. This project does not implement cryptography or WireGuard in JavaScript. The inner TLS layer adds implementation cost but keeps encryption and peer authentication end-to-end through the Node applications, including when a tunnel ends on a gateway. It is not the fewest possible layers.

## Run locally

Requirements: maintained Node.js 24 or newer, and OpenSSL 3 for the demo certificate generator. Runtime client/server do not invoke OpenSSL commands. Tested using Node 24.19.0 / OpenSSL CLI 3.0.13 on Linux.

From the extracted project folder:

```bash
npm run demo:setup
npm start
```

In another terminal in the same folder:

```bash
npm run ping
node client.js demo/client.json message "Hello Octo"
```

Expect `pong` for ping and `accepted` for a message. Response IDs vary.
The default server logs metadata only. It does **not** store message content.
To see received content, stop the default server and run:

```bash
node examples/receiver.js demo/server.json
```

Then send another message. This example intentionally prints content as JSON.
CLI text arguments may appear in shell history and process listings; use the programmatic API for sensitive content.

No `npm install` is needed. Run `npm test` for the authentication and protocol tests.
Local mode binds only to `127.0.0.1`; it does not use or test WireGuard.
Demo setup creates fresh keys each time in a new directory and refuses overwrites.
Demo leaf certificates expire after seven days; the demo CA expires after 30 days.
To make a new demo later, supply a new directory to `node scripts/create-demo.js DIRECTORY`, then use that directory's configs. Do not reuse demo keys in production.

## Application API

```javascript
const { send } = require('./client');
const { load } = require('./lib/config');

send(load('demo/client.json'), 'message', { text: 'Hello Octo' })
  .then(response => console.log(response))
  .catch(error => console.error(error.message));
```

Server integration:

```javascript
const { createChannelServer } = require('./server');
const { load } = require('./lib/config');

const channel = createChannelServer(load('demo/server.json'), {
  onMessage: ({ peer, id, text }) => {
    // Synchronous, short receiver. Peer identity was checked before this call.
    // Treat text as data; enforce further permission checks for any actual action.
    console.log(JSON.stringify({ peer, id, text }));
  }
});

channel.listen()
  .then(address => console.log(address))
  .catch(error => console.error(error.message));
```

`onMessage` must be synchronous and quick; promises are not awaited. A thrown error closes the connection without an acknowledgement. Do not put blocking work here. For durable asynchronous processing, implement a bounded durable queue and acknowledgement semantics before extending this starter. The example acknowledgement means validation succeeded and the synchronous callback returned; it does not mean durable storage or execution completed.

## Security boundaries

| Boundary | Implementation |
|---|---|
| Network exposure | Literal private/loopback IPv4 binding; non-loopback server requires the configured local interface |
| Application encryption | TLS 1.3 only, using Node/OpenSSL |
| Server identity | Explicit private CA, normal certificate validity and IP SAN checks, plus SHA-256 leaf certificate pin |
| Client identity | Mandatory valid client certificate, exact enrolled leaf fingerprint, expected source address |
| Permissions | Each enrolled peer may use only its configured `ping` / `message` operations |
| Protocol | Required ALPN `secure-node/1`, four-byte big-endian length followed by UTF-8 JSON |
| Input bounds | 8192-byte JSON frame, 4096-byte message text, exact field sets, strict UTF-8 |
| Resource bounds | 64 concurrent sockets, 3-second handshake timeout, 5-second total connection deadline |
| Per-peer limit | Burst of 20 authenticated connections, refilling at 5 per second; memory bounded by configured peers |
| Logging | Default logs omit content and keys; logging failures do not grant access |
| Session reuse | Client does not reuse sessions; server rejects resumed application sessions |

Request shape: `{ "v": 1, "id": "UUID", "op": "message", "body": { "text": "Hello" } }`.
Ping uses `"op": "ping", "body": {}`. Every connection carries one request and one response.
Unknown operations, extra fields and invalid messages close the channel. The server takes peer identity from the certificate, never a claimed JSON identity. It does not execute commands or pass content to a model.

TLS protects records against network replay within its protocol. **This is not application-level exactly-once delivery.** A permitted sender can submit the same logical message again on another connection. A lost response leaves the sender uncertain whether the receiver accepted the request. There are no automatic retries, persistent message deduplication, offline inboxes, or server push in this starter. Add durable idempotency before using messages to trigger side effects.

## WireGuard deployment: two Linux endpoint hosts

1. Provision two maintained hosts with WireGuard and Node.js. Choose a tunnel subnet that does not overlap your existing routes. The examples use server `10.77.0.1` and client `10.77.0.2`.
2. Generate each WireGuard private key on its own host. Exchange public keys through an authenticated channel. Generate a unique optional preshared key for this pair and transfer it securely:

   ```bash
   umask 077
   wg genkey > wireguard.key
   wg pubkey < wireguard.key > wireguard.pub
   ```

   Run `wg genpsk > pair.psk` once and securely provision the same pair key to both endpoints. These are separate from TLS keys. Do not print private keys into logs or commit them.
3. Fill the `deploy/wg-*.conf.example` placeholders and install the appropriate file on each host as `/etc/wireguard/wg0.conf`, readable only by root. Start it with `sudo wg-quick up wg0`. The client needs the server's public IP; its own public address may be dynamic. No public TCP listener or port forwarding for TCP 9443 is needed. No IP forwarding is needed for this endpoint-to-endpoint design.
4. Issue separate production TLS client/server certificates through your controlled private CA. Generate private keys on the endpoint that owns them; sign CSRs using an offline or otherwise protected issuer. Use `serverAuth` and IP SAN `10.77.0.1` for the server certificate; `clientAuth` for client certificates. Set suitable validity and rotation periods. Do not deploy the CA private key to the server or client. The demo generator is for local testing only.
5. Use the generated demo JSON files as structural templates, replacing all file paths, pins and identities with production values. On the server set `host` to `10.77.0.1`, add `"interface": "wg0"`, and set the client's peer `address` to `10.77.0.2`. On the client set `host` to `10.77.0.1`; optionally set `localAddress` to `10.77.0.2`. Keep port `9443`. The server interface check is a startup check, not a substitute for ingress firewalling.
6. Read production leaf fingerprints with `openssl x509 -in server.crt -noout -fingerprint -sha256` and the equivalent client command. Copy only the colon-separated fingerprint into the matching config field. Verify enrollment through a trusted channel. Trust only the intended private CA in `ca`.
7. Apply a reviewed host firewall. Use `deploy/channel-guard.nft.example` as an integration fragment to reject TCP 9443 unless traffic arrives over `wg0` from the enrolled peer. Separately use default-deny unsolicited ingress and allow outer UDP 51820, restricted to known public source IPs where possible. Preserve required ICMP/ICMPv6 and your management path. Review cloud security groups as well. A private bind address alone does not prove a packet arrived through WireGuard. The supplied fragment is not a complete host firewall and is not applied by this project.
8. Run the server as a dedicated unprivileged account. `deploy/secure-node-channel.service.example` provides a Linux systemd template. Adjust the Node executable path; provision the `securechannel` account, source at `/opt/secure-node-channel`, and config/certificates at `/etc/secure-node-channel`. Make keys/config readable by that account only (for example `0600`, parent directory `0700`) and keep source administrator-owned. The service has no write access to application storage; an added durable queue needs a reviewed storage path and service permissions.
9. Start the service after WireGuard is established, then run `node client.js /path/to/client.json ping` from the enrolled client. Check that public TCP 9443 is blocked, unauthorised peers cannot connect, and the tunnel carries the request. Test from a separate external host before exposing the system to real traffic.

For more peers, assign unique WireGuard keys and tunnel `/32` addresses, unique TLS identities, and a matching policy entry for each; update the firewall accordingly. Example firewall rules currently permit only one peer.

To revoke a peer, remove its WireGuard peer and TLS policy entry and restart the Node service to drop existing connections. Config edits are not hot-reloaded. Rotation changes a leaf certificate's fingerprint, so update both relevant pins through your trusted administrative process. This starter does not fetch CRLs or implement an OCSP revocation service.

On AWS, this service fits an EC2 host with WireGuard. It cannot run as a persistent inbound TLS listener in Lambda, and API Gateway/CloudFront are not the transport for this design.

## Limits and verification

This is a tested reference implementation, not an audited security product or a claim of immunity to autonomous attack. Node/V8/OpenSSL, the OS, WireGuard, supply chain, keys, and administrators remain trusted components. Authenticated content is still untrusted input for downstream AI or business actions. Runtime vulnerabilities and stolen endpoint credentials remain possible.

TLS handshakes consume resources before the application's rate limit. WireGuard and upstream filtering reduce who can reach that cost. Neither layer prevents upstream bandwidth exhaustion, routing disruption, endpoint compromise or traffic metadata observation. Maintain upstream DoS protection and independent communications where availability matters. This project does not make a post-quantum security guarantee.

The automated suite runs real TLS sessions over loopback, including success, wrong/missing identities, certificate pinning, IP SAN checks, TLS downgrade, ALPN, peer permissions/source address, malformed/oversized data, framing, rate limiting and deadlines. WireGuard, nftables and systemd deployment templates require validation on your target hosts; they are not exercised by the local suite.

References checked 14 September 2026:
- [Node.js TLS API](https://nodejs.org/api/tls.html)
- [WireGuard quick start](https://www.wireguard.com/quickstart/)
- [WireGuard protocol](https://www.wireguard.com/protocol/)
- [WireGuard limitations](https://www.wireguard.com/known-limitations/)
