'use strict';

const tls = require('node:tls');
const { randomUUID } = require('node:crypto');
const { load, pin, checkNetwork } = require('./lib/config');
const { ALPN, exact, frame, reader, validateRequest } = require('./lib/protocol');

function send(config, op, body = {}) {
  return Promise.resolve().then(() => {
    checkNetwork(config);
    const expectedPin = pin(config.serverFingerprint256);
    const request = validateRequest({ v: 1, id: randomUUID(), op, body });
    const encoded = frame(request);
    return new Promise((resolve, reject) => {
      const socket = tls.connect({
        host: config.host, port: config.port,
        ...(config.localAddress ? { localAddress: config.localAddress } : {}),
        key: config.key, cert: config.cert, ca: config.ca,
        minVersion: 'TLSv1.3', maxVersion: 'TLSv1.3', rejectUnauthorized: true,
        ALPNProtocols: [ALPN],
        // Preserve built-in SAN/hostname verification as well as the pin.
        checkServerIdentity: (host, cert) => tls.checkServerIdentity(host, cert) ||
          (cert.fingerprint256 !== expectedPin ? new Error('Server certificate pin mismatch') : undefined)
      });
      let settled = false;
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        clearTimeout(deadline);
        socket.destroy();
        if (error) reject(error); else resolve(value);
      };
      const deadline = setTimeout(() => finish(new Error('Channel deadline exceeded')), 5000);
      socket.once('error', error => finish(error));
      socket.once('close', () => finish(new Error('Channel closed without a valid response')));
      socket.once('secureConnect', () => {
        if (!socket.authorized || socket.alpnProtocol !== ALPN || socket.isSessionReused() ||
            socket.getPeerCertificate().fingerprint256 !== expectedPin) return finish(new Error('Server authentication failed'));
        socket.on('data', reader(value => {
          if (!exact(value, ['v', 'id', 'ok', 'result']) || value.v !== 1 || value.id !== request.id ||
              value.ok !== true || value.result !== (op === 'ping' ? 'pong' : 'accepted')) {
            return finish(new Error('Invalid response'));
          }
          finish(null, value);
        }, error => finish(error)));
        socket.write(encoded);
      });
    });
  });
}

if (require.main === module) {
  Promise.resolve().then(() => {
    const [, , file, op, text] = process.argv;
    if (!file || !op) throw new Error('Usage: node client.js CONFIG.json ping|message [TEXT]');
    return send(load(file), op, op === 'message' ? { text } : {});
  }).then(result => console.log(JSON.stringify(result)))
    .catch(error => { console.error(error.message); process.exitCode = 1; });
}

module.exports = { send };
